# Message Handling System Implementation Guide

## Overview
This guide outlines the step-by-step implementation of the new modular message handling system. The system is designed with clear separation of concerns, making it easier to maintain and update individual components without affecting others.

## System Architecture

### Core Components
1. **MessageHandler** (`backend/message_processing/message_handler.py`)
   - Main orchestrator for message processing
   - Manages conversation state and flow
   - Coordinates between services
   - Handles error recovery and retries

2. **StageService** (`backend/message_processing/stage_service.py`)
   - Manages conversation stages
   - Handles stage transitions
   - Validates stage configurations

3. **TemplateService** (`backend/message_processing/template_service.py`)
   - Manages message templates
   - Handles template versioning
   - Provides template caching

4. **DataExtractionService** (`backend/message_processing/data_extraction_service.py`)
   - Extracts structured data from messages
   - Validates extracted data
   - Manages extraction rules

5. **LLMService** (`backend/ai/llm_service.py`)
   - Interfaces with language models
   - Manages API rate limiting
   - Handles retries and fallbacks

### Directory Structure
```
backend/
├── message_processing/
│   ├── core/
│   │   ├── message_handler.py        # Main orchestrator
│   │   ├── stage_manager.py          # Stage management
│   │   └── context_manager.py        # Context management
│   ├── stages/
│   │   ├── stage_selector.py         # Stage selection logic
│   │   ├── data_extractor.py         # Data extraction logic
│   │   └── response_generator.py      # Response generation logic
│   ├── services/
│   │   ├── llm_service.py            # LLM integration
│   │   ├── template_service.py       # Template management
│   │   └── validation_service.py     # Input validation
│   └── storage/
│       ├── state_manager.py          # State management
│       └── cache_manager.py          # Caching layer
```

## Configuration

### 1. Environment Variables
```bash
# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=icmp_db
DB_USER=icmp_user
DB_PASSWORD=secure_password
DB_POOL_SIZE=20
DB_POOL_TIMEOUT=30

# Redis Configuration
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0
REDIS_PASSWORD=
REDIS_SSL=false
REDIS_POOL_SIZE=10

# LLM Configuration
LLM_API_KEY=your-api-key
LLM_API_ENDPOINT=https://api.openai.com/v1
LLM_MODEL=gpt-4
LLM_MAX_TOKENS=2000
LLM_TEMPERATURE=0.7

# Rate Limiting
RATE_LIMIT_REQUESTS_PER_MINUTE=60
RATE_LIMIT_TOKENS_PER_MINUTE=40000

# Cache Configuration
CACHE_TTL_TEMPLATES=3600
CACHE_TTL_STAGES=3600
CACHE_TTL_CONVERSATIONS=1800
```

### 2. Database Schema
```sql
-- Additional tables needed for enhanced functionality

-- Stage Transitions
CREATE TABLE IF NOT EXISTS stage_transitions (
    transition_id UUID PRIMARY KEY,
    from_stage_id UUID REFERENCES stages(stage_id),
    to_stage_id UUID REFERENCES stages(stage_id),
    business_id UUID REFERENCES businesses(business_id),
    condition TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
    log_id UUID PRIMARY KEY,
    business_id UUID REFERENCES businesses(business_id),
    user_id UUID REFERENCES users(user_id),
    action_type VARCHAR(50),
    action_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Performance Indexes
CREATE INDEX IF NOT EXISTS idx_stage_transitions_business ON stage_transitions(business_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_business ON audit_logs(business_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action_type);
```

## Implementation Phases

### Phase 1: Core Infrastructure (Week 1)

#### 1.1 State Management
```python
# backend/state/redis_manager.py
class RedisStateManager:
    def __init__(self, redis_client):
        self.redis = redis_client
        self.default_ttl = 3600  # 1 hour

    async def set_conversation_state(self, conversation_id: str, state: Dict):
        key = f"conv:{conversation_id}:state"
        await self.redis.set(key, json.dumps(state), ex=self.default_ttl)

    async def get_conversation_state(self, conversation_id: str) -> Optional[Dict]:
        key = f"conv:{conversation_id}:state"
        data = await self.redis.get(key)
        return json.loads(data) if data else None
```

#### 1.2 Error Handling
```python
# backend/errors/message_errors.py
class MessageProcessingError(Exception):
    """Base class for message processing errors."""
    pass

class StageTransitionError(MessageProcessingError):
    """Error during stage transition."""
    pass

class TemplateError(MessageProcessingError):
    """Error in template processing."""
    pass

class DataExtractionError(MessageProcessingError):
    """Error during data extraction."""
    pass
```

### Phase 2: Message Processing (Week 2)

#### 2.1 Enhanced Message Handler
```python
# backend/message_processing/message_handler.py
class MessageHandler:
    def __init__(self, db_pool, redis_manager, llm_service=None):
        self.db_pool = db_pool
        self.redis_manager = redis_manager
        self.llm_service = llm_service or LLMService(db_pool)
        self.stage_service = StageService(db_pool)
        self.template_service = TemplateService(redis_manager)
        self.data_extraction_service = DataExtractionService(db_pool, llm_service)

    async def process_message(self, message_data: Dict[str, Any]) -> Dict[str, Any]:
        log_id = str(uuid.uuid4())
        try:
            # Validate input
            self._validate_message_data(message_data)
            
            # Get or create conversation with retry
            conversation_id = await self._get_or_create_conversation_with_retry(
                message_data['business_id'],
                message_data['user_id'],
                message_data.get('conversation_id')
            )
            
            # Process message with error recovery
            result = await self._process_with_error_recovery(
                conversation_id,
                message_data
            )
            
            # Update state
            await self._update_conversation_state(conversation_id, result)
            
            return result
            
        except MessageProcessingError as e:
            return self._handle_processing_error(e, log_id)
        except Exception as e:
            return self._handle_unexpected_error(e, log_id)
```

### Phase 3: Services (Week 3)

#### 3.1 Rate Limiter
```python
# backend/services/rate_limiter.py
class RateLimiter:
    def __init__(self, redis_client):
        self.redis = redis_client
        
    async def check_rate_limit(self, key: str, limit: int, window: int) -> bool:
        current = await self.redis.get(key)
        if current and int(current) >= limit:
            return False
        await self.redis.incr(key)
        await self.redis.expire(key, window)
        return True
```

#### 3.2 Circuit Breaker
```python
# backend/services/circuit_breaker.py
class CircuitBreaker:
    def __init__(self, redis_client):
        self.redis = redis_client
        
    async def is_open(self, service: str) -> bool:
        return await self.redis.get(f"circuit:{service}:open") == "1"
        
    async def record_failure(self, service: str):
        failures = await self.redis.incr(f"circuit:{service}:failures")
        if failures >= 5:  # Threshold
            await self.redis.set(f"circuit:{service}:open", "1", ex=300)  # 5 minutes
```

### Phase 4: Testing (Week 4)

#### 4.1 Test Configuration
```python
# tests/conftest.py
import pytest
import asyncio
from backend.db import get_db_pool
from backend.state.redis_manager import RedisStateManager
from backend.services.rate_limiter import RateLimiter

@pytest.fixture
async def db_pool():
    pool = await get_db_pool()
    yield pool
    await pool.close()

@pytest.fixture
async def redis_manager():
    redis = await get_redis_client()
    manager = RedisStateManager(redis)
    yield manager
    await redis.close()

@pytest.fixture
async def rate_limiter():
    redis = await get_redis_client()
    limiter = RateLimiter(redis)
    yield limiter
    await redis.close()
```

#### 4.2 Integration Tests
```python
# tests/test_message_handling.py
class TestMessageHandler:
    async def test_message_processing(self):
        # Setup
        handler = MessageHandler(
            db_pool=self.db_pool,
            redis_manager=self.redis_manager
        )
        
        # Test message processing
        result = await handler.process_message({
            'business_id': 'test_business',
            'user_id': 'test_user',
            'content': 'test message'
        })
        
        # Verify result
        assert result['success'] is True
        assert 'response' in result
```

## API Documentation

### Message Processing Endpoints

#### POST /api/message
Process a new message.

**Request Body:**
```json
{
    "business_id": "uuid",
    "user_id": "uuid",
    "content": "string",
    "conversation_id": "uuid (optional)"
}
```

**Response:**
```json
{
    "success": true,
    "conversation_id": "uuid",
    "message_id": "uuid",
    "response": "string",
    "stage_id": "uuid"
}
```

## Deployment Guide

### 1. Prerequisites
- Python 3.8+
- PostgreSQL 12+
- Redis 6+
- Docker (optional)

### 2. Installation
```bash
# Clone repository
git clone https://github.com/your-repo/icmp-events-api.git
cd icmp-events-api

# Create virtual environment
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows

# Install dependencies
pip install -r requirements.txt

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration

# Initialize database
python setup_database.py
```

### 3. Running the Service
```bash
# Development
python run_local.py

# Production
gunicorn -w 4 -k uvicorn.workers.UvicornWorker backend.app:app
```

### 4. Monitoring
- Set up Prometheus metrics
- Configure Grafana dashboards
- Set up alerting rules
- Monitor error rates and response times

## Maintenance Guide

### 1. Database Maintenance
- Regular backups
- Index optimization
- Vacuum analysis
- Connection pool monitoring

### 2. Cache Management
- Monitor cache hit rates
- Adjust TTL values
- Clear stale data
- Monitor memory usage

### 3. Error Handling
- Monitor error rates
- Review error logs
- Update error handling
- Maintain fallback responses

### 4. Performance Optimization
- Monitor response times
- Optimize database queries
- Adjust cache settings
- Scale resources as needed