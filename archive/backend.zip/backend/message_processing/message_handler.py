"""
Message handler for processing incoming messages.

This module handles the orchestration of message processing,
utilizing the StageService and TemplateService to determine the
appropriate processing flow and apply templates.
"""

import logging
import uuid
import re
import json
from typing import Dict, Any, Optional, Tuple, List
from datetime import datetime

from backend.ai.llm_service import LLMService
from backend.db import get_db_connection, release_db_connection, execute_query
from backend.message_processing.template_variables import TemplateVariableProvider
from backend.message_processing.stage_service import StageService
from backend.message_processing.template_service import TemplateService
from backend.message_processing.data_extraction_service import DataExtractionService
from backend.message_processing.ai_control_service import ai_control_service
from backend.db.connection_manager import ConnectionManager

log = logging.getLogger(__name__)

class MessageHandler:
    """
    Handler for processing incoming messages.
    
    Coordinates the message processing flow by working with various services
    to determine the current stage, apply appropriate templates, and generate responses.
    """
    
    # In-memory storage for process logs
    _process_logs = {}
    
    # In-memory storage for stop flags per conversation
    _stop_flags = {}
    
    def __init__(self, db_pool, llm_service: LLMService = None):
        """
        Initialize the message handler.
        
        Args:
            db_pool: Database connection pool
            llm_service: Optional LLM service instance for generating responses
        """
        self.db_pool = db_pool
        self.connection_manager = ConnectionManager(db_pool)
        self.llm_service = llm_service or LLMService(db_pool=db_pool)
        self.stage_service = StageService(db_pool)
        self.template_service = TemplateService()
        self.data_extraction_service = DataExtractionService(db_pool, self.llm_service)
    
    def stop_ai_responses(self, conversation_id: str) -> None:
        """
        Stop AI from generating responses for a specific conversation.
        
        Args:
            conversation_id: The ID of the conversation to stop
        """
        self._stop_flags[conversation_id] = True
        log.info(f"AI responses stopped for conversation {conversation_id}")
    
    def resume_ai_responses(self, conversation_id: str) -> None:
        """
        Resume AI response generation for a specific conversation.
        
        Args:
            conversation_id: The ID of the conversation to resume
        """
        self._stop_flags[conversation_id] = False
        log.info(f"AI responses resumed for conversation {conversation_id}")
    
    def is_ai_stopped(self, conversation_id: str) -> bool:
        """
        Check if AI responses are stopped for a conversation.
        
        Args:
            conversation_id: The ID of the conversation to check
            
        Returns:
            bool: True if AI responses are stopped, False otherwise
        """
        return self._stop_flags.get(conversation_id, False)
    
    def process_message(self, message_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process an incoming message.
        
        Args:
            message_data: Dictionary containing message data
            
        Returns:
            Dictionary containing the response
        """
        log_id = str(uuid.uuid4())
        self._store_process_log(log_id, {
            'status': 'started',
            'timestamp': datetime.now().isoformat(),
            'message_data': message_data
        })
        
        try:
            # Extract required fields
            business_id = message_data.get('business_id')
            user_id = message_data.get('user_id')
            content = message_data.get('content')
            initial_conversation_id = message_data.get('conversation_id')
            api_key = message_data.get('api_key')
            owner_id = message_data.get('owner_id')
            
            # Validate required fields
            if not all([business_id, user_id, content]):
                self._store_process_log(log_id, {
                    'status': 'error',
                    'error': "Missing required fields: business_id, user_id, content",
                    'timestamp': datetime.now().isoformat()
                })
                return {
                    'success': False,
                    'error': "Missing required fields: business_id, user_id, content"
                }
            
            # Check if AI responses are stopped for this user
            if ai_control_service.is_ai_stopped(None, user_id):
                log.info(f"AI responses are stopped for user {user_id}")
                return {
                    'success': True,
                    'response': None,
                    'conversation_id': None,
                    'message_id': None,
                    'response_id': None,
                    'process_log_id': log_id,
                    'ai_stopped': True
                }
            
            # Process the message using the connection manager
            def process_with_connection(conn):
                # Get or create conversation
                current_conversation_id = self._get_or_create_conversation(conn, business_id, user_id, initial_conversation_id)
                
                # Process the message
                result = self._process_message_with_connection(
                    conn, current_conversation_id, business_id, user_id, content
                )
                
                return result
            
            result = self.connection_manager.execute_with_retry(process_with_connection)
            
            self._store_process_log(log_id, {
                'status': 'completed',
                'timestamp': datetime.now().isoformat(),
                'result': result
            })
            
            return result
            
        except Exception as e:
            log.error(f"Error processing message: {str(e)}", exc_info=True)
            self._store_process_log(log_id, {
                'status': 'error',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            })
            return {
                'success': False,
                'error': str(e),
                'process_log_id': log_id
            }
    
    def _process_message_with_connection(self, conn, conversation_id: str, business_id: str, 
                                       user_id: str, content: str) -> Dict[str, Any]:
        """Process a message with an existing connection."""
        try:
            # Save the user message
            message_id = self._save_message(conn, conversation_id, content, 'user', user_id)
            
            # Get current stage and process
            stage_info = self.stage_service.get_current_stage(conversation_id)
            if not stage_info:
                return {
                    'success': False,
                    'error': "Could not determine conversation stage",
                    'conversation_id': conversation_id,
                    'message_id': message_id
                }
            
            # Process the message based on stage
            response = self._process_stage_message(
                conn, conversation_id, business_id, user_id, content, stage_info
            )
            
            # Update conversation timestamp
            self._update_conversation_timestamp(conn, conversation_id)
            
            return {
                'success': True,
                'conversation_id': conversation_id,
                'message_id': message_id,
                'response_id': response.get('response_id'),
                'response': response.get('content'),
                'stage_id': stage_info.get('stage_id')
            }
            
        except Exception as e:
            log.error(f"Error in _process_message_with_connection: {str(e)}", exc_info=True)
            raise
    
    def _process_stage_message(self, conn, conversation_id, business_id, user_id, content, stage_info):
        """
        Process a message based on the current stage.
        
        Args:
            conn: Database connection
            conversation_id: ID of the conversation
            business_id: ID of the business
            user_id: ID of the user
            content: Message content
            stage_info: Dictionary containing stage information
            
        Returns:
            Dictionary containing response information
        """
        try:
            # Get the template IDs for this stage
            stage_id = stage_info.get('stage_id')
            stage_selection_template_id = stage_info.get('stage_selection_template_id')
            data_extraction_template_id = stage_info.get('data_extraction_template_id')
            response_generation_template_id = stage_info.get('response_generation_template_id')
            
            # Build context for template substitution
            context = {
                'business_id': business_id,
                'user_id': user_id,
                'conversation_id': conversation_id,
                'message_content': content,
                'stage_id': stage_id,
                'stage_name': stage_info.get('stage_name'),
                'stage_description': stage_info.get('stage_description')
            }
            
            # Generate values for template variables
            variable_values = TemplateVariableProvider.generate_variable_values(
                conn=conn,
                business_id=business_id,
                user_id=user_id,
                conversation_id=conversation_id,
                message_content=content
            )
            context.update(variable_values)
            
            # Step 1: Data Extraction if template exists
            extracted_data = None
            if data_extraction_template_id:
                extraction_template = self.template_service.get_template(conn, data_extraction_template_id)
                if extraction_template:
                    applied_template = self.template_service.apply_template(extraction_template, context)
                    extraction_input = applied_template['content']
                    extraction_system_prompt = applied_template.get('system_prompt', '')
                    
                    # Generate extraction response using LLM
                    extracted_data = self.llm_service.generate_response(
                        input_text=extraction_input,
                        system_prompt=extraction_system_prompt,
                        conversation_id=conversation_id,
                        business_id=business_id,
                        call_type="extraction"
                    )
                    context['extracted_data'] = extracted_data
            
            # Step 2: Generate Response
            response_content = None
            if response_generation_template_id:
                response_template = self.template_service.get_template(conn, response_generation_template_id)
                if response_template:
                    applied_template = self.template_service.apply_template(response_template, context)
                    response_input = applied_template['content']
                    response_system_prompt = applied_template.get('system_prompt', '')
                    
                    # Generate response using LLM
                    response_content = self.llm_service.generate_response(
                        input_text=response_input,
                        system_prompt=response_system_prompt,
                        conversation_id=conversation_id,
                        business_id=business_id,
                        call_type="response"
                    )
            
            # If no response generated, use a default message
            if not response_content:
                response_content = "I'm processing your message. Please wait a moment."
            
            # Save the response message
            response_id = self._save_message(conn, conversation_id, response_content, 'assistant', user_id)
            
            return {
                'response_id': response_id,
                'content': response_content,
                'extracted_data': extracted_data
            }
            
        except Exception as e:
            log.error(f"Error in _process_stage_message: {str(e)}", exc_info=True)
            # Return a fallback response
            response_id = self._save_message(conn, conversation_id, "I encountered an error processing your message. Please try again.", 'assistant', user_id)
            return {
                'response_id': response_id,
                'content': "I encountered an error processing your message. Please try again.",
                'extracted_data': None
            }
    
    def _get_or_create_conversation(self, conn, business_id: str, user_id: str, 
                                  conversation_id: Optional[str] = None) -> str:
        """Get existing conversation or create a new one."""
        def get_or_create_with_connection(conn):
            cursor = conn.cursor()
            
            try:
                # First, check if the user exists
                cursor.execute(
                    """
                    SELECT user_id FROM users WHERE user_id = %s
                    """,
                    (user_id,)
                )
                if not cursor.fetchone():
                    # User doesn't exist, create them
                    cursor.execute(
                        """
                        INSERT INTO users (
                            user_id, first_name, last_name, email, created_at
                        )
                        VALUES (%s, %s, %s, %s, NOW())
                        """,
                        (user_id, 'NEW', 'User', f'auto-{user_id}@example.com')
                    )
                    conn.commit()  # Commit the user creation
                    log.info(f"Created new user: {user_id}")
                
                # If conversation_id is provided, verify it exists
                if conversation_id:
                    cursor.execute(
                        """
                        SELECT conversation_id, status 
                        FROM conversations 
                        WHERE conversation_id = %s AND business_id = %s AND user_id = %s
                        """,
                        (conversation_id, business_id, user_id)
                    )
                    result = cursor.fetchone()
                    
                    if result:
                        return result[0]
                    else:
                        log.warning(f"Conversation {conversation_id} not found, creating new one")
                
                # Create new conversation
                return self._create_conversation(conn, business_id, user_id)
                
            finally:
                cursor.close()
        
        return self.connection_manager.execute_with_retry(get_or_create_with_connection)

    def _save_message(self, conn, conversation_id: str, content: str, sender_type: str, user_id: str = None, stage_id: str = None, status: str = 'delivered') -> str:
        """Save a message to the database."""
        def save_with_connection(conn):
            cursor = conn.cursor()
            try:
                message_id = str(uuid.uuid4())
                now = datetime.now()
                
                # Log the insert attempt
                log.info(f"Attempting to insert message: id={message_id}, conversation={conversation_id}, user={user_id}, sender={sender_type}")
                log.info(f"Message content: {content[:100]}...")  # Log first 100 chars
                
                # First check if this message already exists
                cursor.execute(
                    """
                    SELECT message_id FROM messages 
                    WHERE conversation_id = %s 
                    AND message_content = %s 
                    AND sender_type = %s 
                    AND created_at > NOW() - INTERVAL '5 seconds'
                    """,
                    (conversation_id, content, sender_type)
                )
                existing = cursor.fetchone()
                if existing:
                    log.warning(f"Duplicate message detected, skipping insert. Existing message_id: {existing[0]}")
                    return existing[0]
                
                cursor.execute(
                    """
                    INSERT INTO messages (
                        message_id, conversation_id, user_id, message_content, 
                        sender_type, status, created_at
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        message_id,
                        conversation_id,
                        user_id,
                        content,
                        sender_type,
                        status,
                        now
                    )
                )
                
                # Explicitly commit the transaction
                conn.commit()
                log.info(f"Successfully inserted message {message_id}")
                
                return message_id
            except Exception as e:
                log.error(f"Error inserting message: {str(e)}", exc_info=True)
                conn.rollback()
                raise
            finally:
                cursor.close()
                
        return self.connection_manager.execute_with_retry(save_with_connection)

    def _update_conversation_timestamp(self, conn, conversation_id: str) -> None:
        """Update the conversation's last activity timestamp."""
        def update_with_connection(conn):
            cursor = conn.cursor()
            try:
                cursor.execute(
                    """
                    UPDATE conversations 
                    SET last_updated = NOW() 
                    WHERE conversation_id = %s
                    """,
                    (conversation_id,)
                )
            finally:
                cursor.close()
        
        self.connection_manager.execute_with_retry(update_with_connection)

    def _create_conversation(self, conn, business_id: str, user_id: str) -> str:
        """Create a new conversation."""
        def create_with_connection(conn):
            cursor = conn.cursor()
            try:
                conversation_id = str(uuid.uuid4())
                cursor.execute(
                    """
                    INSERT INTO conversations (
                        conversation_id, business_id, user_id, status, start_time, last_updated
                    )
                    VALUES (%s, %s, %s, 'active', NOW(), NOW())
                    """,
                    (conversation_id, business_id, user_id)
                )
                conn.commit()  # Commit the conversation creation
                return conversation_id
            finally:
                cursor.close()
        
        return self.connection_manager.execute_with_retry(create_with_connection)

    def _get_stage_name(self, conn, stage_id):
        """Get the name of a stage by its ID."""
        def get_with_connection(conn):
            cursor = conn.cursor()
            try:
                cursor.execute(
                    """
                    SELECT name FROM stages WHERE stage_id = %s
                    """,
                    (stage_id,)
                )
                result = cursor.fetchone()
                return result[0] if result else None
            finally:
                cursor.close()
        
        return self.connection_manager.execute_with_retry(get_with_connection)

    def _get_available_stages(self, conn, business_id: str) -> List[str]:
        """Get all available stages for a business."""
        def get_with_connection(conn):
            cursor = conn.cursor()
            try:
                cursor.execute(
                    """
                    SELECT stage_id, name FROM stages 
                    WHERE business_id = %s 
                    ORDER BY name
                    """,
                    (business_id,)
                )
                return [{'stage_id': row[0], 'name': row[1]} for row in cursor.fetchall()]
            finally:
                cursor.close()
        
        return self.connection_manager.execute_with_retry(get_with_connection)

    def validate_stage_selection_response(self, response: str) -> str:
        """Validate and clean the stage selection response."""
        if not response:
            log.warning("Empty stage selection response, defaulting to 'not_sure'")
            return "not_sure"
        
        # Clean the response
        cleaned_response = response.strip().lower()
        log.debug(f"Cleaned stage selection response: '{cleaned_response}'")
        
        # List of valid stages with aliases
        valid_stages = {
            "default": ["default", "default conversation", "default stage", "initial"],
            "introduction": ["intro", "introduction", "greeting", "welcome"],
            "products": ["product", "products", "catalog", "offering"],
            "not_sure": ["not sure", "unclear", "unknown", "unsure"],
            "test": ["test", "testing", "debug"]
        }
        
        # Try to match the response against stage names and their aliases
        for stage, aliases in valid_stages.items():
            for alias in aliases:
                if alias in cleaned_response:
                    log.info(f"Matched stage '{stage}' via alias '{alias}' in response: '{cleaned_response}'")
                    return stage
        
        # If no match found, try to extract any stage-like words
        words = cleaned_response.split()
        for word in words:
            for stage, aliases in valid_stages.items():
                if any(alias.startswith(word) for alias in aliases):
                    log.info(f"Partial match found for stage '{stage}' from word '{word}'")
                    return stage
        
        # If still no match, check if response contains any stage-related keywords
        stage_keywords = {
            "default": ["conversation", "general", "basic"],
            "introduction": ["hello", "hi", "hey", "greet"],
            "products": ["buy", "purchase", "price", "cost"],
            "not_sure": ["help", "confused", "what", "how"],
            "test": ["check", "verify", "testing"]
        }
        
        for stage, keywords in stage_keywords.items():
            if any(keyword in cleaned_response for keyword in keywords):
                log.info(f"Matched stage '{stage}' via keyword in response: '{cleaned_response}'")
                return stage
        
        # If no valid stage found, log extensively and return default
        log.warning(f"No valid stage match found in response: '{response}'")
        log.warning("Original response content length: %d", len(response))
        log.warning("Cleaned response content length: %d", len(cleaned_response))
        log.warning("Words in cleaned response: %s", words)
        
        return "not_sure"

    def _generate_conversation_summary(self, messages: List[Dict], business_id: str) -> str:
        """Generate a summary of the conversation using the LLM service."""
        try:
            # Format messages for summary generation
            formatted_messages = []
            for msg in messages:
                role = "assistant" if msg["is_from_agent"] else "user"
                formatted_messages.append({
                    "role": role,
                    "content": msg["content"]
                })
            
            # Generate summary using LLM service
            summary_prompt = """Please analyze this conversation and provide a structured summary with the following sections:
1. Overview: A brief summary of the main topic and purpose
2. Key Points: Important information discussed
3. Decisions: Any decisions made or agreements reached
4. Pending Items: Topics that need follow-up
5. Next Steps: Recommended actions
6. Sentiment: Overall tone of the conversation
7. Confidence Score: How confident you are in this summary (0-1)

Format the response as a JSON object with these exact keys."""

            summary = self.llm_service.generate_response(
                business_id=business_id,
                input_text=json.dumps(formatted_messages),
                system_prompt=summary_prompt,
                call_type="summary"
            )
            
            # Validate that the summary is valid JSON
            try:
                json.loads(summary)  # This will raise an error if the JSON is invalid
                return summary  # Return the JSON string if valid
            except json.JSONDecodeError:
                # If the summary is not valid JSON, create a basic structure
                basic_summary = {
                    "overview": "Unable to generate structured summary",
                    "key_points": [],
                    "decisions": [],
                    "pending_items": [],
                    "next_steps": [],
                    "sentiment": "neutral",
                    "confidence_score": 0.0
                }
                return json.dumps(basic_summary)
            
        except Exception as e:
            log.error(f"Error generating conversation summary: {str(e)}")
            return None

    def _update_conversation(self, conversation_id: str, business_id: str, user_id: str, 
                            content: str, is_from_agent: bool, stage_id: Optional[str] = None,
                            llm_call_id: Optional[str] = None) -> None:
        """Update conversation with new message and optional stage change."""
        def update_with_connection(conn):
            cursor = conn.cursor()
            try:
                # Update conversation timestamp
                cursor.execute(
                    """
                    UPDATE conversations 
                    SET updated_at = NOW() 
                    WHERE conversation_id = %s
                    """,
                    (conversation_id,)
                )
                # Save the message using the unified method
                sender_type = 'agent' if is_from_agent else 'user'
                try:
                    log.info(f"[update_conversation] Saving message for conversation {conversation_id}, user {user_id}, sender_type {sender_type}, stage_id {stage_id}")
                    self._save_message(conn, conversation_id, content, sender_type, user_id, stage_id)
                    log.info(f"[update_conversation] Message saved for conversation {conversation_id}")
                except Exception as e:
                    log.error(f"[update_conversation] Error saving message: {e}")
                    raise
                # Update stage if provided
                if stage_id:
                    cursor.execute(
                        """
                        UPDATE conversations 
                        SET stage_id = %s 
                        WHERE conversation_id = %s
                        """,
                        (stage_id, conversation_id)
                    )
            finally:
                cursor.close()
        self.connection_manager.execute_with_retry(update_with_connection)

    @classmethod
    def _store_process_log(cls, log_id: str, log_data: Dict[str, Any]) -> None:
        """Store a process log in the in-memory storage."""
        cls._process_logs[log_id] = log_data

    @classmethod
    def get_process_log(cls, log_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a process log by ID."""
        return cls._process_logs.get(log_id)

    @classmethod
    def get_recent_process_logs(cls, business_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Retrieve recent process logs for a business."""
        business_logs = [
            log for log in cls._process_logs.values()
            if log.get('business_id') == business_id
        ]
        return sorted(
            business_logs,
            key=lambda x: x.get('start_time', ''),
            reverse=True
        )[:limit]