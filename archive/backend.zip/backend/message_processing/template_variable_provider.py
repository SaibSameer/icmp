import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class TemplateVariableProvider:
    def __init__(self, conn):
        self.conn = conn

    def get_test_context(self, business_id, agent_id):
        """
        Generate a test context with sample data for template variable substitution.
        This provides realistic test data for template testing.
        """
        try:
            # Get business and agent info
            with self.conn.cursor() as cur:
                # Get business info
                cur.execute("""
                    SELECT name, description 
                    FROM businesses 
                    WHERE business_id = %s
                """, (business_id,))
                business = cur.fetchone()

                # Get agent info
                cur.execute("""
                    SELECT name, description 
                    FROM agents 
                    WHERE agent_id = %s AND business_id = %s
                """, (agent_id, business_id))
                agent = cur.fetchone()

                # Get a sample user
                cur.execute("""
                    SELECT user_id, name, email, phone
                    FROM users 
                    WHERE business_id = %s 
                    LIMIT 1
                """, (business_id,))
                user = cur.fetchone()

            # Create test context with sample data
            context = {
                # Business context
                'business': {
                    'id': business_id,
                    'name': business['name'] if business else 'Test Business',
                    'description': business['description'] if business else 'Test Business Description'
                },
                # Agent context
                'agent': {
                    'id': agent_id,
                    'name': agent['name'] if agent else 'Test Agent',
                    'description': agent['description'] if agent else 'Test Agent Description'
                },
                # User context
                'user': {
                    'id': user['user_id'] if user else 'test_user_123',
                    'name': user['name'] if user else 'Test User',
                    'email': user['email'] if user else 'test@example.com',
                    'phone': user['phone'] if user else '+1234567890'
                },
                # System context
                'system': {
                    'timestamp': datetime.now().isoformat(),
                    'version': '1.0.0'
                },
                # Sample conversation context
                'conversation': {
                    'id': 'test_conversation_123',
                    'start_time': datetime.now().isoformat(),
                    'last_message': 'Hello, how can I help you today?',
                    'stage': 'greeting'
                },
                # Sample data extraction context
                'extracted_data': {
                    'name': 'John Doe',
                    'email': 'john@example.com',
                    'phone': '+1234567890',
                    'preferences': ['email', 'sms'],
                    'last_interaction': '2024-03-20T10:00:00Z'
                },
                # Additional realistic test values for common template variables
                'message_content': "How do I update my account information?",
                'available_stages': ["Account Update", "Billing", "Support", "Technical Help"],
                'field_name': "account_number",
                'fields_to_extract': ["account_number", "email", "phone"],
                'response': "Your account information has been updated successfully.",
                'stage': "Account Update",
                'stage_list': ["Account Update", "Billing", "Support"],
                'conversation_history': [
                    {"sender": "user", "content": "Hi, I need help with my account."},
                    {"sender": "assistant", "content": "Sure, what do you need to update?"}
                ],
            }

            return context

        except Exception as e:
            logger.error(f"Error generating test context: {str(e)}")
            # Return a basic context if database operations fail
            return {
                'business': {'id': business_id, 'name': 'Test Business'},
                'agent': {'id': agent_id, 'name': 'Test Agent'},
                'user': {'id': 'test_user_123', 'name': 'Test User'},
                'system': {'timestamp': datetime.now().isoformat()},
                'conversation': {'id': 'test_conversation_123', 'stage': 'greeting'},
                'extracted_data': {'name': 'John Doe', 'email': 'john@example.com'}
            } 