from db import get_db_connection, release_db_connection
import logging
import uuid
from typing import Dict, List, Optional, Union
import json

log = logging.getLogger(__name__)

class TemplateManager:
    @staticmethod
    def get(template_id: str) -> dict:
        """Retrieve template with validation metadata"""
        conn = get_db_connection()
        try:
            with conn.cursor() as c:
                c.execute('''
                    SELECT template_id, template_text, variables, template_type, metadata
                    FROM default_templates
                    WHERE template_id = %s;
                ''', (template_id,))
                result = c.fetchone()
                if not result:
                    raise ValueError(f"Template {template_id} not found")
                return {
                    'id': result[0],
                    'text': result[1],
                    'variables': result[2],
                    'type': result[3],
                    'metadata': result[4] if result[4] else {}
                }
        except Exception as e:
            log.error(f"Template fetch failed: {str(e)}")
            raise
        finally:
            release_db_connection(conn)

    @staticmethod
    def validate_placeholders(template_id: str, context: dict) -> bool:
        """Verify all required placeholders are provided"""
        template = TemplateManager.get(template_id)
        if template is None:
            raise ValueError(f"No Template found for: {template_id}")

        required_vars = set(template['variables'])
        provided_vars = set(context.keys())

        missing = required_vars - provided_vars
        if missing:
            raise ValueError(f"Missing variables for template {template_id}: {missing}")
        return True

    @staticmethod
    def render(template_id: str, context: dict) -> str:
        """Render template with context after validation"""
        TemplateManager.validate_placeholders(template_id, context)
        template = TemplateManager.get(template_id)
        if template is None:
            raise ValueError(f"No Template found for: {template_id}")
        return template['text'].format(**context)

    @staticmethod
    def create(template_data: Dict[str, Union[str, List[str], Dict]]) -> str:
        """Create a new template"""
        conn = get_db_connection()
        try:
            template_id = str(uuid.uuid4())
            with conn.cursor() as c:
                c.execute('''
                    INSERT INTO default_templates 
                    (template_id, template_text, variables, template_type, metadata)
                    VALUES (%s, %s, %s, %s, %s)
                    RETURNING template_id;
                ''', (
                    template_id,
                    template_data['text'],
                    template_data['variables'],
                    template_data.get('type', 'default'),
                    json.dumps(template_data.get('metadata', {}))
                ))
                return c.fetchone()[0]
        except Exception as e:
            log.error(f"Template creation failed: {str(e)}")
            raise
        finally:
            release_db_connection(conn)

    @staticmethod
    def update(template_id: str, template_data: Dict[str, Union[str, List[str], Dict]]) -> bool:
        """Update an existing template"""
        conn = get_db_connection()
        try:
            with conn.cursor() as c:
                c.execute('''
                    UPDATE default_templates 
                    SET template_text = %s,
                        variables = %s,
                        template_type = %s,
                        metadata = %s
                    WHERE template_id = %s
                    RETURNING template_id;
                ''', (
                    template_data['text'],
                    template_data['variables'],
                    template_data.get('type', 'default'),
                    json.dumps(template_data.get('metadata', {})),
                    template_id
                ))
                return bool(c.fetchone())
        except Exception as e:
            log.error(f"Template update failed: {str(e)}")
            raise
        finally:
            release_db_connection(conn)

    @staticmethod
    def delete(template_id: str) -> bool:
        """Delete a template"""
        conn = get_db_connection()
        try:
            with conn.cursor() as c:
                c.execute('''
                    DELETE FROM default_templates 
                    WHERE template_id = %s
                    RETURNING template_id;
                ''', (template_id,))
                return bool(c.fetchone())
        except Exception as e:
            log.error(f"Template deletion failed: {str(e)}")
            raise
        finally:
            release_db_connection(conn)

    @staticmethod
    def list_templates(template_type: Optional[str] = None) -> List[Dict]:
        """List all templates, optionally filtered by type"""
        conn = get_db_connection()
        try:
            with conn.cursor() as c:
                if template_type:
                    c.execute('''
                        SELECT template_id, template_text, variables, template_type, metadata
                        FROM default_templates
                        WHERE template_type = %s;
                    ''', (template_type,))
                else:
                    c.execute('''
                        SELECT template_id, template_text, variables, template_type, metadata
                        FROM default_templates;
                    ''')
                results = c.fetchall()
                return [{
                    'id': r[0],
                    'text': r[1],
                    'variables': r[2],
                    'type': r[3],
                    'metadata': r[4] if r[4] else {}
                } for r in results]
        except Exception as e:
            log.error(f"Template listing failed: {str(e)}")
            raise
        finally:
            release_db_connection(conn)