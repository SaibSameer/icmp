# ICMP Events API Structure Documentation

## Current Directory Structure

```
backend/
├── api/                    # API versioning and endpoints
├── routes/                 # Route definitions
├── services/              # Business logic services
├── message_processing/    # Message handling logic
├── database/             # Database related code
├── schemas/              # API schemas and validation
├── migrations/           # Database migrations
├── db/                   # Database utilities
├── templates/            # Template management
├── monitoring/           # Monitoring and logging
├── utils/                # Utility functions
├── ai/                   # AI and LLM related code
├── tests/                # Test files
└── documentation/        # Documentation files
```

## Current API Endpoints

### Core Endpoints
- `/` - Home route
- `/ping` - Health check
- `/health` - Detailed health status
- `/api/admin-check` - Admin key validation

### Authentication & Authorization
- `/api/auth/*` - Authentication endpoints
- `/api/save-config` - Save user/business configuration
- `/api/lookup-owner` - Business owner lookup
- `/api/verify-owner` - Owner verification

### Business Management
- `/api/businesses/*` - Business CRUD operations
- `/api/config/*` - Configuration management
- `/api/users/*` - User management

### Message Handling
- `/api/messages/*` - Message processing
- `/api/routing/*` - Message routing
- `/api/conversations/*` - Conversation management
- `/api/simulate/*` - Message simulation

### Template Management
- `/api/templates/*` - Template CRUD
- `/api/template-admin/*` - Template administration
- `/api/template-variables/*` - Template variables
- `/api/template-test/*` - Template testing

### AI & LLM
- `/api/llm/*` - LLM operations
- `/api/data-extraction/*` - Data extraction
- `/api/agents/*` - Agent management

### Other Services
- `/api/stages/*` - Stage management
- `/api/privacy/*` - Privacy controls
- `/api/user-stats/*` - User statistics

## Current Architecture Analysis

### Strengths
1. Modular route organization
2. Clear separation of concerns
3. Comprehensive error handling
4. Built-in monitoring and logging
5. Database connection pooling
6. CORS configuration
7. Rate limiting support

### Areas for Improvement
1. No explicit API versioning
2. Some endpoint paths could be more RESTful
3. Inconsistent error response formats
4. Mixed concerns in some route handlers
5. Limited documentation
6. No standardized response format

## Proposed Endpoint Update Plan

### Phase 1: Standardization
1. Implement consistent response format:
```json
{
    "status": "success|error",
    "data": {},
    "error": {
        "code": "ERROR_CODE",
        "message": "Error description"
    },
    "metadata": {
        "timestamp": "ISO8601",
        "version": "1.0"
    }
}
```

2. Standardize error codes and messages
3. Add request/response validation
4. Implement proper logging

### Phase 2: Versioning
1. Add version prefix to all endpoints:
   - `/api/v1/*` for current endpoints
   - Keep backward compatibility
2. Document versioning strategy
3. Add version deprecation notices

### Phase 3: RESTful Improvements
1. Standardize resource naming
2. Implement proper HTTP methods
3. Add proper status codes
4. Implement HATEOAS where appropriate

### Phase 4: Documentation
1. Add OpenAPI/Swagger documentation
2. Create endpoint usage examples
3. Document authentication flows
4. Add rate limiting information

### Phase 5: Testing & Monitoring
1. Add endpoint tests
2. Implement performance monitoring
3. Add usage analytics
4. Set up alerting

## Implementation Strategy

1. **Preparation**
   - Create backup of current endpoints
   - Set up testing environment
   - Document current behavior

2. **Phased Rollout**
   - Start with non-critical endpoints
   - Test thoroughly before deployment
   - Monitor for issues
   - Roll back if needed

3. **Documentation**
   - Update API documentation
   - Create migration guides
   - Document breaking changes

4. **Monitoring**
   - Set up endpoint monitoring
   - Track usage patterns
   - Monitor error rates

## Next Steps

1. Review and approve the proposed plan
2. Set up testing environment
3. Create detailed implementation schedule
4. Begin with Phase 1 implementation
5. Regular progress reviews

## Notes
- All changes should be backward compatible
- Each phase should be independently deployable
- Regular testing and validation required
- Documentation should be updated continuously 