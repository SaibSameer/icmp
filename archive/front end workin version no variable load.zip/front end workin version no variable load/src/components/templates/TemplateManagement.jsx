import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
    Box,
    Typography,
    Button,
    Container,
    Paper,
    List,
    ListItem,
    ListItemText,
    IconButton,
    TextField,
    Grid,
    Divider,
    CircularProgress,
    Alert,
    Tooltip
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import RefreshIcon from '@mui/icons-material/Refresh';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import TemplateVariablesWindow from './TemplateVariablesWindow';
import { getTemplates, createTemplate, updateTemplate } from '../../services/templateService';

function TemplateManagement() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const businessId = searchParams.get('businessId');
    const agentId = searchParams.get('agentId');

    // State management
    const [templates, setTemplates] = useState([]);
    const [filteredTemplates, setFilteredTemplates] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [variablesWindowOpen, setVariablesWindowOpen] = useState(false);
    const [selectedTemplate, setSelectedTemplate] = useState(null);
    const [showBusinessIdInput, setShowBusinessIdInput] = useState(false);
    const [businessApiKey, setBusinessApiKey] = useState('');

    // Template types for filtering
    const templateTypes = [
        { value: 'stage_selection', label: 'Stage Selection', group: 'Regular' },
        { value: 'data_extraction', label: 'Data Extraction', group: 'Regular' },
        { value: 'response_generation', label: 'Response Generation', group: 'Regular' },
        { value: 'default_stage_selection', label: 'Default Stage Selection', group: 'Default' },
        { value: 'default_data_extraction', label: 'Default Data Extraction', group: 'Default' },
        { value: 'default_response_generation', label: 'Default Response Generation', group: 'Default' }
    ];

    useEffect(() => {
        if (businessId && agentId) {
            fetchTemplates();
        }
    }, [businessId, agentId]);

    useEffect(() => {
        setFilteredTemplates(templates);
    }, [templates]);

    const fetchTemplates = async () => {
        setLoading(true);
        setError('');
        try {
            const response = await getTemplates(businessId, agentId);
            setTemplates(response);
        } catch (err) {
            console.error("Failed to fetch templates:", err);
            setError('Failed to fetch templates. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    const handleCreateNewTemplate = () => {
        setSelectedTemplate(null);
        setVariablesWindowOpen(true);
    };

    const handleEditTemplate = (template) => {
        setSelectedTemplate(template);
        setVariablesWindowOpen(true);
    };

    const handleNavigateToHome = () => {
        navigate('/');
    };

    const isDefaultTemplate = (type) => {
        return type.startsWith('default_');
    };

    return (
        <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
            <Paper sx={{ p: 3, mb: 4 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <IconButton onClick={handleNavigateToHome} sx={{ mr: 1 }}>
                        <ArrowBackIcon />
                    </IconButton>
                    <Typography variant="h5" component="h1" gutterBottom sx={{ flexGrow: 1 }}>
                        Template Management
                    </Typography>
                    <Button
                        variant="outlined"
                        color="primary"
                        onClick={fetchTemplates}
                        startIcon={<RefreshIcon />}
                        sx={{ mr: 2 }}
                    >
                        Refresh Templates
                    </Button>
                    <Button
                        variant="contained"
                        color="primary"
                        onClick={handleCreateNewTemplate}
                        startIcon={<AddIcon />}
                    >
                        Create Template
                    </Button>
                </Box>

                <Divider sx={{ mb: 3 }} />

                {showBusinessIdInput && (
                    <Box sx={{ mb: 3, p: 2, border: '1px dashed', borderColor: 'warning.main', borderRadius: 1 }}>
                        <Typography variant="subtitle1" color="warning.main" gutterBottom>
                            Business Credentials Required
                        </Typography>
                        <Grid container spacing={2}>
                            <Grid item xs={12} md={5}>
                                <TextField
                                    fullWidth
                                    label="Business ID"
                                    value={businessId || ''}
                                    disabled
                                    helperText="Required for managing templates"
                                />
                            </Grid>
                            <Grid item xs={12} md={5}>
                                <TextField
                                    fullWidth
                                    label="Business API Key"
                                    value={businessApiKey}
                                    onChange={(e) => setBusinessApiKey(e.target.value)}
                                    placeholder="Enter your business API key"
                                    helperText="Required for authentication"
                                    type="password"
                                    required
                                />
                            </Grid>
                        </Grid>
                    </Box>
                )}

                {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

                {loading ? (
                    <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
                        <CircularProgress />
                    </Box>
                ) : (
                    <>
                        {filteredTemplates.length === 0 ? (
                            <Alert severity="info">
                                No templates found. Create your first template to get started.
                            </Alert>
                        ) : (
                            <List sx={{ bgcolor: 'background.paper' }}>
                                {filteredTemplates.map((template) => (
                                    <ListItem
                                        key={template.template_id}
                                        button
                                        onClick={() => handleEditTemplate(template)}
                                        sx={{ 
                                            mb: 1,
                                            borderLeft: isDefaultTemplate(template.template_type) ? '4px solid #f50057' : 'none',
                                            bgcolor: isDefaultTemplate(template.template_type) ? 'rgba(245, 0, 87, 0.04)' : 'background.paper'
                                        }}
                                    >
                                        <ListItemText
                                            primary={template.template_name}
                                            secondary={
                                                <>
                                                    <Typography component="span" variant="body2" color="text.primary">
                                                        Type: {template.template_type}
                                                    </Typography>
                                                    <br />
                                                    <Typography component="span" variant="body2" color="text.secondary">
                                                        Content: {template.content.substring(0, 100)}...
                                                    </Typography>
                                                </>
                                            }
                                        />
                                        <Tooltip title="Edit Template">
                                            <IconButton edge="end" onClick={(e) => {
                                                e.stopPropagation();
                                                handleEditTemplate(template);
                                            }}>
                                                <EditIcon />
                                            </IconButton>
                                        </Tooltip>
                                    </ListItem>
                                ))}
                            </List>
                        )}
                    </>
                )}
            </Paper>

            <TemplateVariablesWindow
                open={variablesWindowOpen}
                onClose={() => setVariablesWindowOpen(false)}
                onVariableSelect={(variable) => {
                    // Handle variable selection
                    console.log('Selected variable:', variable);
                }}
            />
        </Container>
    );
}

export default TemplateManagement;
