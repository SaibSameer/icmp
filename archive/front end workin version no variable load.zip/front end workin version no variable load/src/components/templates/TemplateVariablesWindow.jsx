import React, { useState, useEffect } from 'react';
import {
    Box,
    Typography,
    Button,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    List,
    ListItem,
    ListItemText,
    IconButton,
    TextField,
    InputAdornment,
    Tooltip,
    CircularProgress,
    Alert,
} from '@mui/material';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import SearchIcon from '@mui/icons-material/Search';
import templateService from '../../services/templateService';

const TemplateVariablesWindow = ({ open, onClose, onVariableSelect }) => {
    const [variables, setVariables] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        console.log('TemplateVariablesWindow mounted/updated');
        console.log('Dialog open state:', open);
        if (open) {
            console.log('Dialog opened, fetching variables...');
            fetchVariables();
        }
    }, [open]);

    const fetchVariables = async () => {
        console.log('Starting fetchVariables...');
        setLoading(true);
        setError(null);
        try {
            console.log('Calling templateService.getTemplateVariables()...');
            const data = await templateService.getTemplateVariables();
            console.log('Received template variables:', data);
            console.log('Number of variables received:', data.length);
            setVariables(data);
        } catch (err) {
            console.error('Error in fetchVariables:', err);
            console.error('Error details:', {
                message: err.message,
                stack: err.stack,
                name: err.name
            });
            setError(err.message || 'Failed to fetch template variables');
        } finally {
            setLoading(false);
            console.log('Fetch variables completed. Loading:', false);
        }
    };

    const handleVariableClick = (variable) => {
        console.log('Variable clicked:', variable);
        const variableText = `{{${variable.variable_name}}}`;
        console.log('Inserting variable text:', variableText);
        if (typeof onVariableSelect === 'function') {
            onVariableSelect(variableText);
        } else {
            console.error('onVariableSelect is not a function:', onVariableSelect);
        }
        onClose();
    };

    const handleCopyVariable = (variable) => {
        console.log('Copying variable:', variable);
        const variableText = `{{${variable.variable_name}}}`;
        navigator.clipboard.writeText(variableText)
            .then(() => console.log('Variable copied to clipboard:', variableText))
            .catch(err => console.error('Failed to copy variable:', err));
    };

    const renderExampleValue = (value) => {
        console.log('Rendering example value:', value);
        if (typeof value === 'object' && value !== null) {
            if (Array.isArray(value)) {
                return value.map((item, index) => (
                    <Typography key={index} variant="caption" color="text.secondary">
                        {typeof item === 'object' ? JSON.stringify(item) : item}
                    </Typography>
                ));
            } else {
                return (
                    <Typography variant="caption" color="text.secondary">
                        {JSON.stringify(value)}
                    </Typography>
                );
            }
        }
        return (
            <Typography variant="caption" color="text.secondary">
                {value}
            </Typography>
        );
    };

    const filteredVariables = variables.filter(variable =>
        variable.variable_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (variable.description && variable.description.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    console.log('Current state:', {
        variablesCount: variables.length,
        filteredCount: filteredVariables.length,
        loading,
        error,
        searchTerm
    });

    return (
        <Dialog
            open={open}
            onClose={onClose}
            maxWidth="md"
            fullWidth
        >
            <DialogTitle>
                <Typography variant="h6">Available Template Variables</Typography>
                <TextField
                    fullWidth
                    variant="outlined"
                    size="small"
                    placeholder="Search variables..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    sx={{ mt: 1 }}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <SearchIcon />
                            </InputAdornment>
                        ),
                    }}
                />
            </DialogTitle>
            <DialogContent>
                {loading ? (
                    <Box display="flex" justifyContent="center" p={3}>
                        <CircularProgress />
                    </Box>
                ) : error ? (
                    <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>
                ) : (
                    <List>
                        {filteredVariables.length === 0 ? (
                            <ListItem>
                                <ListItemText 
                                    primary="No variables found" 
                                    secondary={searchTerm ? "Try a different search term" : "No variables available"}
                                />
                            </ListItem>
                        ) : (
                            filteredVariables.map((variable) => (
                                <ListItem
                                    key={variable.variable_id}
                                    button
                                    onClick={() => handleVariableClick(variable)}
                                    secondaryAction={
                                        <Tooltip title="Copy variable">
                                            <IconButton
                                                edge="end"
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleCopyVariable(variable);
                                                }}
                                            >
                                                <ContentCopyIcon />
                                            </IconButton>
                                        </Tooltip>
                                    }
                                >
                                    <ListItemText
                                        primary={`{{${variable.variable_name}}}`}
                                        secondary={
                                            <Box>
                                                <Typography variant="body2" color="text.secondary">
                                                    {variable.description || 'No description available'}
                                                </Typography>
                                                {variable.example_value && (
                                                    <Typography variant="caption" display="block" color="text.secondary">
                                                        Example: {renderExampleValue(variable.example_value)}
                                                    </Typography>
                                                )}
                                            </Box>
                                        }
                                    />
                                </ListItem>
                            ))
                        )}
                    </List>
                )}
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose}>Close</Button>
            </DialogActions>
        </Dialog>
    );
};

export default TemplateVariablesWindow; 