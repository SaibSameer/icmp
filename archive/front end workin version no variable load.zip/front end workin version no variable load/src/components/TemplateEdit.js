import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import {
    Box,
    Paper,
    Typography,
    TextField,
    Button,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    CircularProgress,
    Alert,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    DialogContentText,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import { API_CONFIG } from '../config';

function TemplateEdit() {
    const { businessId, templateId } = useParams();
    const location = useLocation();
    const navigate = useNavigate();
    const query = new URLSearchParams(location.search);
    const agentId = query.get('agent_id');

    const [template, setTemplate] = useState({
        template_name: '',
        content: '',
        system_prompt: '',
        template_type: '',
        business_id: businessId
    });

    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [deleting, setDeleting] = useState(false);
    const [error, setError] = useState(null);
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

    const adminApiKey = sessionStorage.getItem('adminApiKey');

    useEffect(() => {
        const fetchTemplate = async () => {
            if (!businessId || !templateId || !adminApiKey) {
                setError('Missing required parameters');
                setLoading(false);
                return;
            }

            try {
                const response = await fetch(`${API_CONFIG.BASE_URL}/api/templates/${templateId}?business_id=${businessId}`, {
                    headers: {
                        'Authorization': `Bearer ${adminApiKey}`,
                        'Accept': 'application/json'
                    }
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.message || `HTTP error ${response.status}`);
                }

                const data = await response.json();
                setTemplate({
                    template_name: data.template_name || '',
                    content: data.content || '',
                    system_prompt: data.system_prompt || '',
                    template_type: data.template_type || '',
                    business_id: businessId
                });
            } catch (err) {
                console.error('Error fetching template:', err);
                setError(`Failed to fetch template: ${err.message}`);
            } finally {
                setLoading(false);
            }
        };

        fetchTemplate();
    }, [businessId, templateId, adminApiKey]);

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setTemplate(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        setSaving(true);
        setError(null);

        try {
            const response = await fetch(`${API_CONFIG.BASE_URL}/api/templates/${templateId}`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${adminApiKey}`,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    ...template,
                    business_id: businessId
                })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || `HTTP error ${response.status}`);
            }

            // Navigate back to stages list with the template
            navigate(`/business/${businessId}/stages?agent_id=${agentId}`);
        } catch (err) {
            console.error('Error updating template:', err);
            setError(`Failed to update template: ${err.message}`);
        } finally {
            setSaving(false);
        }
    };

    const handleDelete = async () => {
        setDeleting(true);
        setError(null);

        try {
            const url = `${API_CONFIG.BASE_URL}/api/templates/${templateId}?business_id=${businessId}`;
            console.log('Attempting to delete template:', {
                url,
                templateId,
                businessId,
                headers: {
                    'Authorization': `Bearer ${adminApiKey}`,
                    'Accept': 'application/json'
                }
            });

            const response = await fetch(url, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${adminApiKey}`,
                    'Accept': 'application/json'
                }
            });

            if (!response.ok) {
                const errorData = await response.json();
                console.error('Delete template error response:', errorData);
                throw new Error(errorData.message || `HTTP error ${response.status}`);
            }

            console.log('Template deleted successfully');
            // Navigate back to stages list after successful deletion
            navigate(`/business/${businessId}/stages?agent_id=${agentId}`);
        } catch (err) {
            console.error('Error deleting template:', err);
            setError(`Failed to delete template: ${err.message}`);
        } finally {
            setDeleting(false);
            setShowDeleteConfirm(false);
        }
    };

    if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
                <CircularProgress />
            </Box>
        );
    }

    return (
        <Box sx={{ mt: 2 }}>
            <Button 
                onClick={() => navigate(`/business/${businessId}/stages?agent_id=${agentId}`)} 
                sx={{ mb: 2 }}
            >
                Back to Stages
            </Button>

            <Paper sx={{ p: 3 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                    <Typography variant="h5">
                        Edit Template
                    </Typography>
                    <Button
                        variant="outlined"
                        color="error"
                        startIcon={<DeleteIcon />}
                        onClick={() => setShowDeleteConfirm(true)}
                        disabled={deleting}
                    >
                        Delete Template
                    </Button>
                </Box>

                {error && (
                    <Alert severity="error" sx={{ mb: 2 }}>
                        {error}
                    </Alert>
                )}

                <form onSubmit={handleSubmit}>
                    <TextField
                        fullWidth
                        label="Template Name"
                        name="template_name"
                        value={template.template_name}
                        onChange={handleInputChange}
                        margin="normal"
                        required
                    />

                    <FormControl fullWidth margin="normal">
                        <InputLabel>Template Type</InputLabel>
                        <Select
                            name="template_type"
                            value={template.template_type}
                            onChange={handleInputChange}
                            required
                        >
                            <MenuItem value="selection">Selection</MenuItem>
                            <MenuItem value="extraction">Extraction</MenuItem>
                            <MenuItem value="generation">Generation</MenuItem>
                        </Select>
                    </FormControl>

                    <TextField
                        fullWidth
                        label="System Prompt"
                        name="system_prompt"
                        value={template.system_prompt}
                        onChange={handleInputChange}
                        margin="normal"
                        multiline
                        rows={3}
                    />

                    <TextField
                        fullWidth
                        label="Template Content"
                        name="content"
                        value={template.content}
                        onChange={handleInputChange}
                        margin="normal"
                        multiline
                        rows={10}
                        required
                    />

                    <Box sx={{ mt: 3, display: 'flex', gap: 2 }}>
                        <Button
                            type="submit"
                            variant="contained"
                            disabled={saving}
                        >
                            {saving ? 'Saving...' : 'Save Changes'}
                        </Button>
                        <Button
                            variant="outlined"
                            onClick={() => navigate(`/business/${businessId}/stages?agent_id=${agentId}`)}
                            disabled={saving}
                        >
                            Cancel
                        </Button>
                    </Box>
                </form>
            </Paper>

            {/* Delete Confirmation Dialog */}
            <Dialog
                open={showDeleteConfirm}
                onClose={() => setShowDeleteConfirm(false)}
            >
                <DialogTitle>Delete Template</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        Are you sure you want to delete this template? This action cannot be undone.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button 
                        onClick={() => setShowDeleteConfirm(false)} 
                        disabled={deleting}
                    >
                        Cancel
                    </Button>
                    <Button 
                        onClick={handleDelete} 
                        color="error" 
                        disabled={deleting}
                        autoFocus
                    >
                        {deleting ? 'Deleting...' : 'Delete'}
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
}

export default TemplateEdit;