import { useState, useEffect, useCallback } from 'react';
import llmService from '../../../services/llmService';

export const useLLMCalls = (internalApiKey, limit = 10) => {
    const [calls, setCalls] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const fetchCalls = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);
            if (!internalApiKey) {
                setError('Internal API key required');
                setCalls([]);
                setLoading(false);
                return;
            }
            const data = await llmService.getRecentCalls(internalApiKey, limit);
            setCalls(data);
        } catch (err) {
            setError(err.message);
            console.error('Error fetching LLM calls:', err);
        } finally {
            setLoading(false);
        }
    }, [internalApiKey, limit]);

    useEffect(() => {
        let mounted = true;
        
        const loadCalls = async () => {
            if (mounted) {
                await fetchCalls();
            }
        };

        loadCalls();

        return () => {
            mounted = false;
        };
    }, [fetchCalls]);

    return {
        calls,
        loading,
        error,
        refreshCalls: fetchCalls
    };
}; 