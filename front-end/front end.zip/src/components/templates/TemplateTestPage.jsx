import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  TextField,
  Button,
  Paper,
  Container,
  CircularProgress,
  Alert,
  Divider,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Grid
} from '@mui/material';
import { useParams } from 'react-router-dom';
import templateService from '../../services/templateService';

function TemplateTestPage() {
  const { businessId } = useParams();
  const [templates, setTemplates] = useState([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [context, setContext] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [testResult, setTestResult] = useState(null);
  const [testLoading, setTestLoading] = useState(false);
  const [contextOverride, setContextOverride] = useState('');

  useEffect(() => {
    if (businessId) {
      fetchTemplates();
    }
  }, [businessId]);

  const fetchTemplates = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await templateService.getTemplates(businessId);
      setTemplates(response);
      if (response.length > 0) {
        setSelectedTemplateId(response[0].template_id);
        setSelectedTemplate(response[0]);
      }
    } catch (err) {
      setError('Failed to fetch templates. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedTemplateId && templates.length > 0) {
      const tmpl = templates.find(t => t.template_id === selectedTemplateId);
      setSelectedTemplate(tmpl);
      setTestResult(null);
      setContextOverride('');
    }
  }, [selectedTemplateId, templates]);

  const handleTest = async () => {
    if (!selectedTemplate) return;
    setTestLoading(true);
    setError('');
    setTestResult(null);
    try {
      // Allow context override for advanced users
      let overrideObj = {};
      if (contextOverride) {
        try {
          overrideObj = JSON.parse(contextOverride);
        } catch (e) {
          setError('Context override must be valid JSON.');
          setTestLoading(false);
          return;
        }
      }
      const result = await templateService.testTemplate(
        businessId,
        null,
        {
          ...selectedTemplate,
          ...overrideObj
        }
      );
      setTestResult(result.content || result.results || result);
    } catch (err) {
      setError('Failed to test template.');
    } finally {
      setTestLoading(false);
    }
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
      <Paper sx={{ p: 3 }}>
        <Typography variant="h5" gutterBottom>
          Template Test Page
        </Typography>
        <Divider sx={{ mb: 3 }} />
        {loading ? (
          <Box display="flex" justifyContent="center" p={3}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel>Select Template</InputLabel>
              <Select
                value={selectedTemplateId}
                label="Select Template"
                onChange={e => setSelectedTemplateId(e.target.value)}
              >
                {templates.map(tmpl => (
                  <MenuItem key={tmpl.template_id} value={tmpl.template_id}>
                    {tmpl.template_name} ({tmpl.template_type})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            {selectedTemplate && (
              <Box sx={{ mb: 2 }}>
                <Typography variant="subtitle1">Template Content:</Typography>
                <Paper variant="outlined" sx={{ p: 2, bgcolor: '#f5f5f5', mb: 2 }}>
                  <pre style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{selectedTemplate.content}</pre>
                </Paper>
                <Typography variant="subtitle2">System Prompt:</Typography>
                <Paper variant="outlined" sx={{ p: 2, bgcolor: '#f5f5f5', mb: 2 }}>
                  <pre style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{selectedTemplate.system_prompt}</pre>
                </Paper>
              </Box>
            )}
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle1">Context Override (optional, JSON):</Typography>
              <TextField
                fullWidth
                multiline
                minRows={3}
                value={contextOverride}
                onChange={e => setContextOverride(e.target.value)}
                placeholder={`{
  "message_content": "Test message"
}`}
              />
            </Box>
            <Button
              variant="contained"
              color="primary"
              onClick={handleTest}
              disabled={testLoading || !selectedTemplateId}
              sx={{ mb: 2 }}
            >
              {testLoading ? <CircularProgress size={20} /> : 'Test Template'}
            </Button>
            {error && <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>}
            {testResult && (
              <Box sx={{ mt: 4 }}>
                <Typography variant="h6" gutterBottom>
                  Test Result
                </Typography>
                <Paper variant="outlined" sx={{ p: 2, bgcolor: '#f5f5f5' }}>
                  <pre style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{JSON.stringify(testResult, null, 2)}</pre>
                </Paper>
              </Box>
            )}
          </>
        )}
      </Paper>
    </Container>
  );
}

export default TemplateTestPage; 