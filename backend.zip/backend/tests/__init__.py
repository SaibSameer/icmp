# file: C:\icmp_events_api\routes\__init__.py
# from flask import Blueprint
# import logging
# from backend.app import app  # Use absolute import

# from routes.businesses import bp as business_bp
# from routes.conversations import bp as conversations_bp
# from routes.health import bp as health_bp
# from routes.message_handling import bp as message_bp
# from routes.ping import bp as ping_bp
# from routes.stages import stages_bp
# from routes.template_management import template_management_bp
# from routes.users import bp as users_bp

# log = logging.getLogger(__name__)

# print("Test file is being executed")

# app.register_blueprint(health_bp, name='health_bp')