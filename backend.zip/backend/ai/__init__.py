"""
AI module for language model services.
"""