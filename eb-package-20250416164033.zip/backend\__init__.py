"""
ICMP Events API - Backend Package

This package contains the backend implementation of the ICMP Events API,
including the Flask application, database operations, and various services.
"""

# This file makes the backend directory a Python package 