"""
Data extraction service for processing and extracting structured data from messages.

This module provides functionality for extracting specific types of data
from user messages based on predefined patterns or LLM-based extraction.
"""

import logging
import json
import re
from typing import Dict, Any, List, Optional, Union
from datetime import datetime

from backend.ai.llm_service import LLMService
from backend.db import get_db_connection, release_db_connection

log = logging.getLogger(__name__)

class DataExtractionService:
    """
    Service for extracting structured data from messages.
    
    This service provides methods for extracting specific types of data
    from user messages based on predefined patterns or LLM-based extraction.
    """
    
    def __init__(self, db_pool, llm_service: Optional[LLMService] = None):
        """
        Initialize the data extraction service.
        
        Args:
            db_pool: Database connection pool
            llm_service: Optional LLM service for advanced extraction
        """
        self.db_pool = db_pool
        self.llm_service = llm_service
    
    def extract_data(self, message_content: str, extraction_template_id: str, 
                    business_id: str, user_id: str, conversation_id: str) -> Dict[str, Any]:
        """
        Extract structured data from a message using a template.
        
        Args:
            message_content: The message to extract data from
            extraction_template_id: ID of the template to use for extraction
            business_id: ID of the business
            user_id: ID of the user
            conversation_id: ID of the conversation
            
        Returns:
            Dictionary containing extracted data
        """
        conn = self.db_pool.getconn()
        try:
            # Get the extraction template
            template = self._get_extraction_template(conn, extraction_template_id)
            if not template:
                log.error(f"Extraction template {extraction_template_id} not found")
                return {"error": "Extraction template not found"}
            
            # Process the template with variable substitution
            processed_template = self._process_template(
                conn, template, business_id, user_id, conversation_id, message_content
            )
            
            # Extract data using the appropriate method
            if self.llm_service:
                extracted_data = self._extract_with_llm(
                    message_content, processed_template, business_id
                )
            else:
                extracted_data = self._extract_with_patterns(
                    message_content, processed_template
                )
            
            # Store the extracted data
            self._store_extracted_data(
                conn, conversation_id, template.get('template_type', 'general'),
                extracted_data
            )
            
            return extracted_data
                
        except Exception as e:
            log.error(f"Error extracting data: {str(e)}")
            return {"error": str(e)}
        finally:
            self.db_pool.putconn(conn)
    
    def _get_extraction_template(self, conn, template_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve an extraction template by ID.
        
        Args:
            conn: Database connection
            template_id: ID of the template
            
        Returns:
            Template data as a dictionary or None if not found
        """
        try:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT template_id, template_name, template_type, content, 
                       system_prompt, business_id
                FROM templates
                WHERE template_id = %s
                """,
                (template_id,)
            )
            
            row = cursor.fetchone()
            if row:
                return {
                    'template_id': row['template_id'],
                    'template_name': row['template_name'],
                    'template_type': row['template_type'],
                    'content': row['content'],
                    'system_prompt': row['system_prompt'],
                    'business_id': row['business_id']
                }
            
            return None
            
        except Exception as e:
            log.error(f"Error retrieving template {template_id}: {str(e)}")
            return None
    
    def _process_template(self, conn, template: Dict[str, Any], business_id: str, 
                         user_id: str, conversation_id: str, message_content: str) -> Dict[str, Any]:
        """
        Process a template with variable substitution.
        
        Args:
            conn: Database connection
            template: Template data
            business_id: ID of the business
            user_id: ID of the user
            conversation_id: ID of the conversation
            message_content: Content of the message
            
        Returns:
            Processed template with variables substituted
        """
        from .template_variables import TemplateVariableProvider
        
        content = template['content']
        system_prompt = template.get('system_prompt', '')
        
        # Extract variables from template
        variables = TemplateVariableProvider.extract_variables_from_template(content)
        system_variables = TemplateVariableProvider.extract_variables_from_template(system_prompt)
        
        # Combine all unique variables
        all_variables = variables.union(system_variables)
        
        # Generate values for template variables
        variable_values = TemplateVariableProvider.generate_variable_values(
            conn, business_id, user_id, conversation_id, message_content, all_variables
        )
        
        # Apply variable substitution
        processed_content = content
        processed_system_prompt = system_prompt
        
        for var_name, var_value in variable_values.items():
            processed_content = processed_content.replace(f"{{{{{var_name}}}}}", str(var_value))
            processed_content = processed_content.replace(f"{{{var_name}}}", str(var_value))
            processed_system_prompt = processed_system_prompt.replace(f"{{{{{var_name}}}}}", str(var_value))
            processed_system_prompt = processed_system_prompt.replace(f"{{{var_name}}}", str(var_value))
        
        return {
            'content': processed_content,
            'system_prompt': processed_system_prompt,
            'template_type': template.get('template_type', 'general')
        }
    
    def _extract_with_llm(self, message_content: str, template: Dict[str, Any], 
                         business_id: str) -> Dict[str, Any]:
        """
        Extract data using LLM-based extraction.
        
        Args:
            message_content: The message to extract from
            template: Processed template with content and system prompt
            business_id: ID of the business
            
        Returns:
            Dictionary with extracted data
        """
        try:
            # Format the prompt for the LLM
            prompt = f"{template['system_prompt']}\n\nMessage: {message_content}\n\nExtract the following information:\n{template['content']}"
            
            # Call the LLM
            response = self.llm_service.generate_response(
                prompt=prompt,
                business_id=business_id,
                call_type="data_extraction"
            )
            
            # Parse the response as JSON
            try:
                extracted_data = json.loads(response)
                return extracted_data
            except json.JSONDecodeError:
                # If not valid JSON, try to extract JSON from the text
                json_match = re.search(r'\{.*\}', response, re.DOTALL)
                if json_match:
                    try:
                        extracted_data = json.loads(json_match.group(0))
                        return extracted_data
                    except json.JSONDecodeError:
                        log.error(f"Failed to parse JSON from LLM response: {response}")
                        return {"raw_extraction": response}
                else:
                    log.error(f"Failed to extract JSON from LLM response: {response}")
                    return {"raw_extraction": response}
        except Exception as e:
            log.error(f"Error using LLM for data extraction: {str(e)}")
            return {"error": str(e)}
    
    def _extract_with_patterns(self, message_content: str, template: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract data using simple pattern matching rules.
        
        Args:
            message_content: The message to extract from
            template: Processed template with content
            
        Returns:
            Dictionary with extracted data
        """
        result = {}
        
        # Simple pattern: field_name: pattern
        pattern_lines = template['content'].strip().split('\n')
        for line in pattern_lines:
            if ':' in line:
                field_name, pattern = line.split(':', 1)
                field_name = field_name.strip()
                pattern = pattern.strip()
                
                # Try to find the pattern in the message
                match = re.search(pattern, message_content, re.IGNORECASE)
                if match:
                    result[field_name] = match.group(1) if match.groups() else match.group(0)
        
        return result
    
    def _store_extracted_data(self, conn, conversation_id: str, data_type: str, 
                             extracted_data: Dict[str, Any]) -> str:
        """
        Store extracted data in the database.
        
        Args:
            conn: Database connection
            conversation_id: ID of the conversation
            data_type: Type of data extracted
            extracted_data: Data to store
            
        Returns:
            ID of the stored extraction
        """
        try:
            cursor = conn.cursor()
            
            # Get the current stage ID from the conversation
            cursor.execute(
                """
                SELECT stage_id FROM conversations WHERE conversation_id = %s
                """,
                (conversation_id,)
            )
            
            result = cursor.fetchone()
            if not result or not result['stage_id']:
                log.warning(f"No current stage found for conversation {conversation_id}")
                return None
            
            stage_id = result['stage_id']
            
            # Insert the extracted data
            cursor.execute(
                """
                INSERT INTO extracted_data 
                (conversation_id, stage_id, data_type, extracted_data, created_at)
                VALUES (%s, %s, %s, %s, %s)
                RETURNING extraction_id
                """,
                (conversation_id, stage_id, data_type, json.dumps(extracted_data), datetime.now())
            )
            
            extraction_id = cursor.fetchone()['extraction_id']
            conn.commit()
            
            return extraction_id
            
        except Exception as e:
            log.error(f"Error storing extracted data: {str(e)}")
            conn.rollback()
            return None
    
    def get_extracted_data(self, conversation_id: str, data_type: Optional[str] = None, 
                          limit: int = 10) -> List[Dict[str, Any]]:
        """
        Retrieve extracted data for a conversation.
        
        Args:
            conversation_id: ID of the conversation
            data_type: Optional filter by data type
            limit: Maximum number of records to return
            
        Returns:
            List of extracted data records
        """
        conn = self.db_pool.getconn()
        try:
            cursor = conn.cursor()
            
            query = """
                SELECT ed.extraction_id, ed.stage_id, ed.data_type, 
                       ed.extracted_data, ed.created_at, s.stage_name
                FROM extracted_data ed
                JOIN stages s ON ed.stage_id = s.stage_id
                WHERE ed.conversation_id = %s
            """
            
            params = [conversation_id]
            
            if data_type:
                query += " AND ed.data_type = %s"
                params.append(data_type)
                
            query += " ORDER BY ed.created_at DESC LIMIT %s"
            params.append(limit)
            
            cursor.execute(query, params)
            results = cursor.fetchall()
            
            # Format the results
            extracted_data = []
            for row in results:
                extracted_data.append({
                    'extraction_id': row['extraction_id'],
                    'stage_id': row['stage_id'],
                    'stage_name': row['stage_name'],
                    'data_type': row['data_type'],
                    'data': row['extracted_data'],
                    'created_at': row['created_at'].isoformat()
                })
            
            return extracted_data
            
        except Exception as e:
            log.error(f"Error retrieving extracted data: {str(e)}")
            return []
        finally:
            self.db_pool.putconn(conn) 