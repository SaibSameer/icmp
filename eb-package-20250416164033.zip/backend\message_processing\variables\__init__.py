"""
Variable providers package.
"""
# Import all variable providers to ensure they're registered
from . import user_name
from . import last_10_messages
from . import available_stages 